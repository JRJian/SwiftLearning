字段说明：

news.other.statusBarStyle
如果需要显示白色状态，设置为:"light"
如果需要显示黑色状态，设置为:"dark"